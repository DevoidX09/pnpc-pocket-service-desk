/**
 * Public JavaScript (patched to submit attachments using FormData and allow removal before post)
 */
(function( $ ) {
	'use strict';

	$(document).ready(function() {
		var selectedFiles = [];

		// On file input change, populate selectedFiles array and render preview list.
		$('#ticket-attachments').on('change', function(e) {
			var files = e.target.files;
			selectedFiles = [];
			for (var i = 0; i < files.length; i++) {
				selectedFiles.push(files[i]);
			}
			renderAttachmentsList();
		});

		function renderAttachmentsList() {
			var $list = $('#pnpc-psd-attachments-list');
			$list.empty();
			if (!selectedFiles.length) {
				return;
			}
			selectedFiles.forEach(function(file, idx) {
				var $item = $('<div/>').addClass('pnpc-psd-attachment-item').css({marginBottom:'6px'});
				$item.append($('<span/>').text(file.name + ' (' + Math.round(file.size/1024) + ' KB)'));
				var $remove = $('<button/>').attr('type','button').addClass('pnpc-psd-button').css({marginLeft:'8px'}).text('Remove');
				$remove.on('click', function() {
					selectedFiles.splice(idx, 1);
					// Reset the real file input by clearing its value and re-render list
					$('#ticket-attachments').val('');
					renderAttachmentsList();
				});
				$item.append($remove);
				$list.append($item);
			});
		}

		// Handle ticket creation form submission (with attachments)
		$('#pnpc-psd-create-ticket-form').on('submit', function(e) {
			e.preventDefault();

			var $form = $(this);
			var subject = $('#ticket-subject').val();
			var description = $('#ticket-description').val();
			var priority = $('#ticket-priority').val();

			if (!subject.trim() || !description.trim()) {
				showMessage('error', 'Please fill in all required fields.');
				return;
			}

			var formData = new FormData();
			formData.append('action', 'pnpc_psd_create_ticket');
			formData.append('nonce', pnpcPsdPublic.nonce);
			formData.append('subject', subject);
			formData.append('description', description);
			formData.append('priority', priority);

			// Attach files from selectedFiles array (so removes take effect)
			for (var i = 0; i < selectedFiles.length; i++) {
				formData.append('attachments[]', selectedFiles[i]);
			}

			$.ajax({
				url: pnpcPsdPublic.ajax_url,
				type: 'POST',
				data: formData,
				processData: false,
				contentType: false,
				success: function(response) {
					if (response.success) {
						showMessage('success', response.data.message + ' (Ticket #' + response.data.ticket_number + ')');
						$form[0].reset();
						selectedFiles = [];
						renderAttachmentsList();

						// Redirect to ticket detail page if provided
						setTimeout(function() {
							if (response.data.ticket_detail_url) {
								window.location.href = response.data.ticket_detail_url;
							} else {
								window.location.href = '?ticket_id=' + response.data.ticket_id;
							}
						}, 1200);
					} else {
						showMessage('error', response.data.message);
					}
				},
				error: function(xhr, status, err) {
					console.error('pnpc-psd-public.js AJAX error', status, err, xhr && xhr.responseText);
					showMessage('error', 'An error occurred. Please try again.');
				}
			});
		});

		// Response submit (no attachments in current UI here, but it supports FormData)
		$('#pnpc-psd-response-form').on('submit', function(e) {
			e.preventDefault();

			var ticketId = $(this).data('ticket-id');
			var response = $('#response-text').val();

			if (!response.trim()) {
				showMessage('error', 'Please enter your response.');
				return;
			}

			var formData = new FormData();
			formData.append('action', 'pnpc_psd_respond_to_ticket');
			formData.append('nonce', pnpcPsdPublic.nonce);
			formData.append('ticket_id', ticketId);
			formData.append('response', response);

			$.ajax({
				url: pnpcPsdPublic.ajax_url,
				type: 'POST',
				data: formData,
				processData: false,
				contentType: false,
				success: function(result) {
					if (result.success) {
						showMessage('success', result.data.message);
						$('#response-text').val('');
						setTimeout(function() {
							location.reload();
						}, 900);
					} else {
						showMessage('error', result.data.message);
					}
				},
				error: function(xhr, status, err) {
					console.error('pnpc-psd-public.js AJAX error', status, err, xhr && xhr.responseText);
					showMessage('error', 'An error occurred. Please try again.');
				}
			});
		});

		function showMessage(type, message) {
			var $messageDiv = $('#ticket-create-message, #response-message').filter(function() {
				return $(this).is(':visible') || $(this).closest('form').length > 0;
			}).first();

			$messageDiv.removeClass('success error').addClass(type).text(message).show();

			setTimeout(function() {
				$messageDiv.fadeOut();
			}, 5000);
		}
	});
})( jQuery );