<?php

/**
 * Public services/products view (standalone).
 *
 * Shows only products allocated to the current user. No general browsing.
 *
 * @package    PNPC_Pocket_Service_Desk
 * @subpackage PNPC_Pocket_Service_Desk/public/views
 */

if (! defined('ABSPATH')) {
    exit;
}

$current_user = wp_get_current_user();
$user_id      = ! empty($current_user->ID) ? (int) $current_user->ID : 0;

// Global toggle: if site-wide products are disabled, do nothing.
$show_products = get_option('pnpc_psd_show_products', 1);
if (! $show_products) {
    echo '<div class="pnpc-psd-services"><p class="pnpc-psd-help-text">';
    esc_html_e('Services are not available at this time.', 'pnpc-pocket-service-desk');
    echo '</p></div>';
    return;
}

// WooCommerce must be active to resolve product objects.
if (! class_exists('WooCommerce')) {
    echo '<div class="pnpc-psd-services"><p class="pnpc-psd-help-text">';
    esc_html_e('Products are not available because WooCommerce is not active.', 'pnpc-pocket-service-desk');
    echo '</p></div>';
    return;
}

// Always show only allocated products for the current user (no general browsing).
if (! $user_id) {
    // Not logged in
    echo '<div class="pnpc-psd-services"><p class="pnpc-psd-help-text">';
    esc_html_e('Please log in to view services allocated to your account.', 'pnpc-pocket-service-desk');
    echo '</p></div>';
    return;
}

// Read allocated product IDs from user meta (stored as comma-separated IDs).
$allocated = get_user_meta($user_id, 'pnpc_psd_allocated_products', true);
$ids       = array();

if (! empty($allocated)) {
    $ids = array_filter(array_map('absint', array_map('trim', explode(',', (string) $allocated))));
    $ids = array_values(array_unique($ids));
}

if (empty($ids)) {
    echo '<div class="pnpc-psd-services"><p class="pnpc-psd-help-text">';
    esc_html_e('No services have been allocated to your account. Please contact an administrator for access.', 'pnpc-pocket-service-desk');
    echo '</p></div>';
    return;
}

// Fetch the allocated products (only published).
$products = wc_get_products(array(
    'include' => $ids,
    'status'  => 'publish',
    'limit'   => -1,
));

if (empty($products)) {
    echo '<div class="pnpc-psd-services"><p class="pnpc-psd-help-text">';
    esc_html_e('Allocated services are not available (they may have been unpublished). Please contact an administrator.', 'pnpc-pocket-service-desk');
    echo '</p></div>';
    return;
}

?>
<div class="pnpc-psd-services">
    <h3><?php esc_html_e('Your Services', 'pnpc-pocket-service-desk'); ?></h3>

    <div class="pnpc-psd-services-list" style="display:flex;gap:16px;flex-wrap:wrap;">
        <?php foreach ($products as $product) :
            // $product is a WC_Product object
            $p_id    = (int) $product->get_id();
            $p_name  = $product->get_name();
            $permalink = get_permalink($p_id);
            $price_html = $product->get_price_html();
        ?>
            <div class="pnpc-psd-service-item" style="flex:0 0 220px;border:1px solid #eee;padding:12px;border-radius:6px;background:#fff;">
                <h4 style="margin:0 0 8px;"><a href="<?php echo esc_url($permalink); ?>"><?php echo esc_html($p_name); ?></a></h4>
                <?php if ($price_html) : ?>
                    <div class="pnpc-psd-service-price" style="margin-bottom:8px;"><?php echo wp_kses_post($price_html); ?></div>
                <?php endif; ?>
                <p><a class="pnpc-psd-button" href="<?php echo esc_url($permalink); ?>"><?php esc_html_e('View / Purchase', 'pnpc-pocket-service-desk'); ?></a></p>
            </div>
        <?php endforeach; ?>
    </div>
</div>