<?php

/**
 * Public service desk dashboard view
 *
 * @package    PNPC_Pocket_Service_Desk
 * @subpackage PNPC_Pocket_Service_Desk/public/views
 */

if (! defined('ABSPATH')) {
	exit;
}

$current_user = wp_get_current_user();
$user_id      = ! empty($current_user->ID) ? (int) $current_user->ID : 0;

// Fetch some tickets for counts (keep behavior as before)
$tickets = PNPC_PSD_Ticket::get_by_user($user_id, array('limit' => 100));
$open_count = count(array_filter($tickets, function ($ticket) {
	return 'open' === $ticket->status || 'in-progress' === $ticket->status;
}));
$closed_count = count(array_filter($tickets, function ($ticket) {
	return 'closed' === $ticket->status;
}));

// Welcome toggle (use existing option); default on.
$show_welcome = (bool) get_option('pnpc_psd_show_welcome', 1);

// Products mode: premium-only toggle
$products_premium_only = (bool) get_option('pnpc_psd_products_premium_only', 0);

?>
<div class="pnpc-psd-dashboard">

	<?php if ($show_welcome && $user_id) : ?>
		<h2><?php printf(esc_html__('Welcome, %s!', 'pnpc-pocket-service-desk'), esc_html($current_user->display_name)); ?></h2>
	<?php endif; ?>

	<!-- Two-column row: Ticket totals (left) / Quick actions (right) -->
	<div class="pnpc-psd-row pnpc-psd-top-row" style="display:flex;gap:20px;flex-wrap:wrap;">
		<div class="pnpc-psd-column" style="flex:1;min-width:240px;">
			<div class="pnpc-psd-stat-box">
				<h3><?php esc_html_e('Ticket Totals', 'pnpc-pocket-service-desk'); ?></h3>
				<ul class="pnpc-psd-stats-list">
					<li><strong><?php echo esc_html($open_count); ?></strong> <?php esc_html_e('Open / In-Progress', 'pnpc-pocket-service-desk'); ?></li>
					<li><strong><?php echo esc_html($closed_count); ?></strong> <?php esc_html_e('Closed', 'pnpc-pocket-service-desk'); ?></li>
				</ul>
			</div>
		</div>

		<div class="pnpc-psd-column" style="flex:1;min-width:240px;">
			<div class="pnpc-psd-quick-actions">
				<h3><?php esc_html_e('Quick Actions', 'pnpc-pocket-service-desk'); ?></h3>
				<p>
					<a href="<?php echo esc_url(home_url('/create-ticket/')); ?>" class="pnpc-psd-button pnpc-psd-button-primary">
						<?php esc_html_e('Create Ticket', 'pnpc-pocket-service-desk'); ?>
					</a>
					<a href="<?php echo esc_url(home_url('/my-tickets/')); ?>" class="pnpc-psd-button">
						<?php esc_html_e('View My Tickets', 'pnpc-pocket-service-desk'); ?>
					</a>
					<?php if (current_user_can('pnpc_psd_view_tickets')) : ?>
						<a href="<?php echo esc_url(admin_url('admin.php?page=pnpc-psd-tickets')); ?>" class="pnpc-psd-button">
							<?php esc_html_e('Manage All Tickets', 'pnpc-pocket-service-desk'); ?>
						</a>
					<?php endif; ?>
				</p>
				<p class="pnpc-psd-help-text">
					<?php esc_html_e('Use these shortcuts to manage or create support tickets quickly.', 'pnpc-pocket-service-desk'); ?>
				</p>
			</div>
		</div>
	</div>

	<!-- Services row (full width) -->
	<div class="pnpc-psd-row pnpc-psd-services-row" style="margin-top:28px;">
		<div class="pnpc-psd-services" style="width:100%;">
			<h3><?php esc_html_e('Services', 'pnpc-pocket-service-desk'); ?></h3>

			<?php
			// Determine which products to show:
			$allocated = $user_id ? get_user_meta($user_id, 'pnpc_psd_allocated_products', true) : '';
			$products_to_show = array();

			// If allocated products exist for this user, prioritize those.
			if (! empty($allocated)) {
				$ids = array_filter(array_map('absint', array_map('trim', explode(',', (string) $allocated))));
				if (! empty($ids) && class_exists('WooCommerce')) {
					$products_to_show = wc_get_products(array('include' => $ids, 'status' => 'publish', 'limit' => -1));
				}
			}

			// If no allocated products and premium-only is disabled, show a standard product list.
			if (empty($products_to_show) && ! $products_premium_only && class_exists('WooCommerce')) {
				$products_to_show = wc_get_products(array('status' => 'publish', 'limit' => 6));
			}

			// Render results
			if (! empty($products_to_show)) :
				echo '<div class="pnpc-psd-services-list" style="display:flex;gap:16px;flex-wrap:wrap;">';
				foreach ($products_to_show as $product) :
					// $product may be WC_Product or an int depending on wc_get_products return.
					if (is_numeric($product)) {
						$product = wc_get_product((int) $product);
					}
					if (! $product) {
						continue;
					}
					$product_id = $product->get_id();
					$permalink  = get_permalink($product_id);
					$title      = $product->get_name();
					$price_html = $product->get_price_html();
			?>
					<div class="pnpc-psd-service-item" style="flex:0 0 220px;border:1px solid #eee;padding:12px;border-radius:6px;background:#fff;">
						<h4 style="margin:0 0 8px;"><a href="<?php echo esc_url($permalink); ?>"><?php echo esc_html($title); ?></a></h4>
						<div class="pnpc-psd-service-price" style="margin-bottom:8px;"><?php echo wp_kses_post($price_html); ?></div>
						<p><a class="pnpc-psd-button" href="<?php echo esc_url($permalink); ?>"><?php esc_html_e('View / Purchase', 'pnpc-pocket-service-desk'); ?></a></p>
					</div>
				<?php
				endforeach;
				echo '</div>';
			else :
				// No products to show (either premium only or WooCommerce missing)
				if ($products_premium_only) :
				?>
					<p class="pnpc-psd-help-text">
						<?php esc_html_e('Services available to you are currently restricted. If you believe you should have access, please contact support.', 'pnpc-pocket-service-desk'); ?>
					</p>
				<?php
				else :
				?>
					<p class="pnpc-psd-help-text">
						<?php esc_html_e('No services are available at this time.', 'pnpc-pocket-service-desk'); ?>
					</p>
			<?php
				endif;
			endif;
			?>
		</div>
	</div>

</div>